<?php
require_once __DIR__ . '/auth.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (loginAdmin($username, $password)) {
        header('Location: index.php');
        exit;
    } else {
        $error = 'Invalid username or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login — Rod Wealth Construction</title>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #0f172a;
    font-family: 'Segoe UI', system-ui, sans-serif;
  }

  .login-wrapper {
    width: 100%;
    max-width: 420px;
    padding: 16px;
  }

  .logo {
    text-align: center;
    margin-bottom: 32px;
  }

  .logo-icon {
    width: 56px;
    height: 56px;
    background: linear-gradient(135deg, #f59e0b, #d97706);
    border-radius: 14px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 14px;
    font-size: 26px;
  }

  .logo h1 {
    color: #f8fafc;
    font-size: 20px;
    font-weight: 700;
    letter-spacing: -0.3px;
  }

  .logo p {
    color: #64748b;
    font-size: 13px;
    margin-top: 4px;
  }

  .card {
    background: #1e293b;
    border: 1px solid #334155;
    border-radius: 16px;
    padding: 36px 32px;
  }

  .card h2 {
    color: #f1f5f9;
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 24px;
  }

  .form-group {
    margin-bottom: 18px;
  }

  label {
    display: block;
    color: #94a3b8;
    font-size: 13px;
    font-weight: 500;
    margin-bottom: 7px;
  }

  input {
    width: 100%;
    padding: 11px 14px;
    background: #0f172a;
    border: 1px solid #334155;
    border-radius: 9px;
    color: #f1f5f9;
    font-size: 15px;
    transition: border-color 0.2s;
    outline: none;
  }

  input:focus {
    border-color: #f59e0b;
  }

  .error-msg {
    background: #450a0a;
    border: 1px solid #7f1d1d;
    color: #fca5a5;
    padding: 11px 14px;
    border-radius: 9px;
    font-size: 13px;
    margin-bottom: 18px;
  }

  .btn {
    width: 100%;
    padding: 12px;
    background: linear-gradient(135deg, #f59e0b, #d97706);
    color: #fff;
    border: none;
    border-radius: 9px;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    transition: opacity 0.2s;
    margin-top: 6px;
  }

  .btn:hover { opacity: 0.9; }

  .back-link {
    text-align: center;
    margin-top: 20px;
  }

  .back-link a {
    color: #64748b;
    font-size: 13px;
    text-decoration: none;
  }

  .back-link a:hover { color: #94a3b8; }
</style>
</head>
<body>

<div class="login-wrapper">
  <div class="logo">
    <div class="logo-icon">🏗️</div>
    <h1>Rod Wealth Construction</h1>
    <p>Admin Dashboard</p>
  </div>

  <div class="card">
    <h2>Sign In</h2>

    <?php if ($error): ?>
      <div class="error-msg">⚠️ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="login.php">
      <div class="form-group">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" placeholder="Enter username"
               value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required autofocus>
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="Enter password" required>
      </div>
      <button type="submit" class="btn">Sign In →</button>
    </form>
  </div>

  <div class="back-link">
    <a href="../index.html">← Back to website</a>
  </div>
</div>

</body>
</html>
