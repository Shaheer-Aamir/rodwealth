// ============================================================
//  FORM INTEGRATION — paste this into your existing JS file
//  or add a <script> tag at the bottom of each page
// ============================================================


// ── HOMEPAGE FORM (index.html) ────────────────────────────
// Fields: name, email, phone, type (project type), message

(function () {
  // homepage form has no #projectType id (that's contact page only)
  if (document.getElementById('projectType')) return;

  const form = document.querySelector('.php-email-form');
  if (!form) return;

  form.addEventListener('submit', async function (e) {
    e.preventDefault();

    const loading   = form.querySelector('.loading');
    const errorEl   = form.querySelector('.error-message');
    const successEl = form.querySelector('.sent-message');
    const btn       = form.querySelector('button[type="submit"]');

    loading.style.display   = 'block';
    errorEl.style.display   = 'none';
    successEl.style.display = 'none';
    btn.disabled = true;

    const formData = new FormData(this);
    formData.append('source', 'homepage');

    try {
      const res  = await fetch('submit.php', { method: 'POST', body: formData });
      const data = await res.json();
      loading.style.display = 'none';

      if (data.success) {
        successEl.style.display = 'block';
        form.reset();
      } else {
        errorEl.textContent     = data.message || 'Something went wrong.';
        errorEl.style.display   = 'block';
      }
    } catch (err) {
      loading.style.display   = 'none';
      errorEl.textContent     = 'Network error. Please try again.';
      errorEl.style.display   = 'block';
    } finally {
      btn.disabled = false;
    }
  });
})();


// ── CONTACT PAGE FORM (contact.html) ─────────────────────
// Fields: name, phone, email, project_type, project_address,
//         budget, timeline, message

(function () {
  const trigger = document.getElementById('projectType');
  if (!trigger) return; // only runs on contact page

  const form = trigger.closest('form');
  if (!form) return;

  form.addEventListener('submit', async function (e) {
    e.preventDefault();

    const loading   = form.querySelector('.loading');
    const errorEl   = form.querySelector('.error-message');
    const successEl = form.querySelector('.sent-message');
    const btn       = form.querySelector('button[type="submit"]');

    loading.style.display   = 'block';
    errorEl.style.display   = 'none';
    successEl.style.display = 'none';
    btn.disabled = true;

    const formData = new FormData(this);
    formData.append('source', 'contact');

    try {
      const res  = await fetch('submit.php', { method: 'POST', body: formData });
      const data = await res.json();
      loading.style.display = 'none';

      if (data.success) {
        successEl.style.display = 'block';
        form.reset();
      } else {
        errorEl.textContent     = data.message || 'Something went wrong.';
        errorEl.style.display   = 'block';
      }
    } catch (err) {
      loading.style.display   = 'none';
      errorEl.textContent     = 'Network error. Please try again.';
      errorEl.style.display   = 'block';
    } finally {
      btn.disabled = false;
    }
  });
})();
